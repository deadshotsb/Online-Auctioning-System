
import os
os.system('start cmd.exe @cmd /k "python main_server.py -cs 127.0.0.1 6000 1"')